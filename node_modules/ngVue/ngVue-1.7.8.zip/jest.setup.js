import 'angular'
import 'angular-mocks'
import './src/index'
